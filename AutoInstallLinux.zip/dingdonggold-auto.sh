#!/bin/bash
wget "https://dl.walletbuilders.com/download?customer=94006b5aeb6d7ad57b4233075b859a21ad7a4250bd9ec36ffd&filename=dingdonggold-qt-linux.tar.gz" -O dingdonggold-qt-linux.tar.gz

mkdir $HOME/Desktop/DingDongGold

tar -xzvf dingdonggold-qt-linux.tar.gz --directory $HOME/Desktop/DingDongGold

mkdir $HOME/.dingdonggold

cat << EOF > $HOME/.dingdonggold/dingdonggold.conf
rpcuser=rpc_dingdonggold
rpcpassword=dR2oBQ3K1zYMZQtJFZeAerhWxaJ5Lqeq9J2
rpcbind=0.0.0.0
rpcallowip=127.0.0.1
listen=1
server=1
addnode=node2.walletbuilders.com
EOF

cat << EOF > $HOME/Desktop/DingDongGold/start_wallet.sh
#!/bin/bash
SCRIPT_PATH=\`pwd\`;
cd \$SCRIPT_PATH
./dingdonggold-qt
EOF

chmod +x $HOME/Desktop/DingDongGold/start_wallet.sh

cat << EOF > $HOME/Desktop/DingDongGold/mine.sh
#!/bin/bash
SCRIPT_PATH=\`pwd\`;
cd \$SCRIPT_PATH
echo Press [CTRL+C] to stop mining.
while :
do
./dingdonggold-cli generatetoaddress 1 \$(./dingdonggold-cli getnewaddress)
done
EOF

chmod +x $HOME/Desktop/DingDongGold/mine.sh

exec $HOME/Desktop/DingDongGold/dingdonggold-qt &

sleep 15

cd $HOME/Desktop/DingDongGold/

clear

exec $HOME/Desktop/DingDongGold/mine.sh